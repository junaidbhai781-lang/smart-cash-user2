# Fortune Hive
Preview: open www/index.html in a browser.
APK: upload this folder to a GitHub repo, then Actions > Build APK > Run workflow, and download the artifact.
Wallet, results and live feed are client-side/simulated in this build. Replace them with a server before any real-money use.
