/* ---------- Lucky777 ---------- */
function slot(gb){
 var SY=[{s:'7️⃣',m:50,w:1},{s:'💎',m:25,w:2},{s:'🔔',m:15,w:3},{s:'🍇',m:10,w:4},{s:'🍉',m:8,w:5},{s:'🍊',m:6,w:6},{s:'🍒',m:4,w:7}];
 var LN=[[1,1,1],[0,0,0],[2,2,2],[0,1,2],[2,1,0]],BETS=[5,10,50,100,500,1000],bi=1,busy=false,auto=false,tw=today.slot||0;
 gb.innerHTML='<div class="stat"><div><b id="tb">10</b><i>Total bet</i></div><div><b id="tw">'+money(tw)+'</b><i>Today\'s win</i></div><div><b id="lw">0</b><i>Win</i></div></div><div class="reels">'+[0,1,2].map(function(){return '<div class="reel">'+'<div class="cell">🔔</div><div class="cell">7️⃣</div><div class="cell">🍇</div></div>'}).join('')+'</div><div class="msg" id="mg">Press spin to play</div><div class="row"><button class="btn" id="bm">BET −</button><button class="btn" id="bp">BET +</button><button class="btn" id="au">AUTO</button></div><div class="row"><button class="btn big" id="sp">SPIN</button></div>';
 var reels=$$('.reel',gb),g=[[],[],[]];
 function cells(c){return $$('.cell',reels[c])}
 function show(c){cells(c).forEach(function(e,r){e.textContent=g[c][r]?g[c][r].s:SY[rnd(7)].s})}
 function upd(){$('#tb',gb).textContent=money(BETS[bi])}
 $('#bm').onclick=function(){if(!busy){bi=Math.max(0,bi-1);upd()}};
 $('#bp').onclick=function(){if(!busy){bi=Math.min(5,bi+1);upd()}};
 $('#au').onclick=function(){auto=!auto;this.classList.toggle('on',auto);if(auto&&!busy)spin()};
 $('#sp').onclick=function(){spin()};
 function spin(){
  var bet=BETS[bi];if(busy)return;
  if(wallet<bet){auto=false;$('#au').classList.remove('on');$('#mg').textContent='Insufficient balance. Tap + to add test balance.';return}
  busy=true;setW(wallet-bet);$('#mg').textContent='';$('#lw').textContent='0';
  $$('.cell',gb).forEach(function(e){e.classList.remove('w')});
  var fin=[0,0,0].map(function(){return [pickW(SY),pickW(SY),pickW(SY)]}),done=0;
  [0,1,2].forEach(function(c){
   var iv=every(function(){g[c]=[];show(c)},70);
   later(function(){clearInterval(iv);g[c]=fin[c];show(c);if(++done==3)settle(bet)},700+c*450)});
 }
 function settle(bet){
  var win=0,hit=[];
  LN.forEach(function(L){var a=g[0][L[0]],b=g[1][L[1]],c=g[2][L[2]];if(a.s==b.s&&b.s==c.s){win+=a.m*bet/5;hit.push([0,L[0]],[1,L[1]],[2,L[2]])}});
  hit.forEach(function(h){cells(h[0])[h[1]].classList.add('w')});
  if(win){setW(wallet+win);tw+=win;today.slot=tw;$('#tw').textContent=money(tw);$('#lw').textContent=money(win);$('#mg').textContent='You won ₹'+money(win)+'!'}
  else $('#mg').textContent='No win. Try again.';
  busy=false;if(auto)later(spin,1100)}
 cleanup=function(){auto=false};
}

