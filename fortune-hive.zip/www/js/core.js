
var $=function(s,r){return(r||document).querySelector(s)},$$=function(s,r){return[].slice.call((r||document).querySelectorAll(s))};
var wallet=5000,timers=[],cleanup=null,today={};
try{var sv=localStorage.getItem('la_w');if(sv!==null&&+sv>=0)wallet=+sv}catch(e){}
function fmt(n){return n>=1000?(n/1000)+'K':String(n)}
function money(n){return n.toLocaleString('en-IN')}
function setW(n){wallet=Math.max(0,Math.round(n));$$('.bal').forEach(function(e){e.textContent=money(wallet)});try{localStorage.setItem('la_w',wallet)}catch(e){}}
function toast(t){var e=$('#toast');e.textContent=t;e.style.display='block';clearTimeout(toast.t);toast.t=setTimeout(function(){e.style.display='none'},1800)}
function later(f,ms){var t=setTimeout(f,ms);timers.push(t);return t}
function every(f,ms){var t=setInterval(f,ms);timers.push(t);return t}
function stopAll(){timers.forEach(function(t){clearTimeout(t);clearInterval(t)});timers=[]}
function pickW(a){var s=0,i;a.forEach(function(x){s+=x.w});var r=Math.random()*s;for(i=0;i<a.length;i++){r-=a[i].w;if(r<0)return a[i]}return a[0]}
function rnd(n){return Math.floor(Math.random()*n)}
setW(wallet);
var NM=['Ra***sh','Pr***ya','Am***t','Su***l','Ni***a','Vi***y','Ka***k','Me***a'],AM=[5,10,50,100,500,1000];
function live(root,own){root.insertAdjacentHTML('afterbegin','<div class="live"><i class="dot"></i><b class="onl"></b><span class="lf"></span></div>');
 var on=2100+rnd(300),o=$('.onl',root),f=$('.lf',root);
 function t(){on+=rnd(21)-10;o.textContent='Online '+on.toLocaleString('en-IN');var a=AM[rnd(6)];f.textContent=NM[rnd(8)]+(Math.random()<.35?' won ₹'+money(a*(2+rnd(8))):' bet ₹'+money(a))}
 t();(own?setInterval:every)(t,1800)}
live($('.hs'),true);

$('#add').onclick=function(){setW(wallet+1000);toast('Added ₹1,000 test balance')};
$$('.g').forEach(function(c){c.onclick=function(){open(c.dataset.g)}});
$$('[data-soon]').forEach(function(b){b.onclick=function(){toast('Coming soon')}});
var td=new Date().toDateString(),cl;try{cl=localStorage.getItem('la_c')}catch(e){}
function chk(){var b=$('#claim');if(cl===td){b.disabled=true;b.textContent='Claimed'}}chk();
$('#claim').onclick=function(){setW(wallet+50);cl=td;try{localStorage.setItem('la_c',td)}catch(e){}chk();toast('+₹50 bonus')};
$('#close').onclick=function(){stopAll();if(cleanup)cleanup();cleanup=null;$('#gv').classList.remove('on');$('#homeV').style.display=''};
function open(g){$('#homeV').style.display='none';$('#gv').classList.add('on');var gb=$('#gb');gb.innerHTML='';({slot:slot,wheel:wheel,greedy:greedy})[g](gb);live(gb)}
var CHIPS=[[5,'#7a4fd0'],[10,'#17a2b8'],[50,'#1fa855'],[100,'#2a6fd4'],[500,'#e8761a'],[1000,'#d8322f']];
function chipsHTML(){return '<div class="chips">'+CHIPS.map(function(c,i){return '<button class="chip'+(i==1?' sel':'')+'" data-v="'+c[0]+'" style="background:'+c[1]+'">'+fmt(c[0])+'</button>'}).join('')+'</div>'}
function chipPick(root){var v=10;$$('.chip',root).forEach(function(b){b.onclick=function(){$$('.chip',root).forEach(function(x){x.classList.remove('sel')});b.classList.add('sel');v=+b.dataset.v}});return function(){return v}}

