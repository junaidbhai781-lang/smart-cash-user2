/* ---------- Super77Pro ---------- */
function wheel(gb){
 var SEG=['🍉','🥭','🍉','🥭','🍉','🥭','7️⃣','🍉'],BX=[{k:'🍉',m:2},{k:'7️⃣',m:8},{k:'🥭',m:2}],hist=[],rot=0,bets=[0,0,0],busy=false,t=10,tw=today.wheel||0;
 gb.innerHTML='<div class="stat"><div><b id="tw">'+money(tw)+'</b><i>Today\'s win</i></div><div><b id="cd">10</b><i>Bet time (s)</i></div></div><div class="ptr"></div><div class="wr"><div class="wheel" id="wh">'+SEG.map(function(e,i){return '<div class="s" style="transform:rotate('+i*45+'deg)"><span>'+e+'</span></div>'}).join('')+'</div><div class="hub" id="hb">1</div></div><div class="hist"><em>Results</em><span id="hs"></span></div><div class="bets">'+BX.map(function(b,i){return '<button class="bx" data-i="'+i+'"><div class="e">'+b.k+'</div><b>x'+b.m+'</b><div class="t">0</div></button>'}).join('')+'</div>'+chipsHTML()+'<div class="msg" id="mg">Pick a chip, then tap a box.</div>';
 var cv=chipPick(gb),bxs=$$('.bx',gb);
 bxs.forEach(function(b){b.onclick=function(){var i=+b.dataset.i,v=cv();if(busy)return toast('Wait for the next round');if(wallet<v)return toast('Insufficient balance');setW(wallet-v);bets[i]+=v;$('.t',b).textContent=money(bets[i])}});
 function round(){busy=false;t=10;bets=[0,0,0];bxs.forEach(function(b){b.classList.remove('win');$('.t',b).textContent='0'});$('#mg').textContent='Place your bets';$('#hb').textContent=t;
  var iv=every(function(){t--;$('#hb').textContent=t;$('#cd').textContent=t;if(t<=0){clearInterval(iv);go()}},1000)}
 function go(){busy=true;$('#mg').textContent='Spinning...';var i=rnd(8);rot+=1800+(((-i*45-rot)%360)+360)%360;$('#wh').style.transform='rotate('+rot+'deg)';
  later(function(){var r=SEG[i],win=0;bxs.forEach(function(b,k){if(BX[k].k==r&&bets[k]){win+=bets[k]*BX[k].m;b.classList.add('win')}});
   hist.unshift(r);hist=hist.slice(0,8);$('#hs').textContent=hist.join(' ');$('#hb').textContent=r;
   if(win){setW(wallet+win);tw+=win;today.wheel=tw;$('#tw').textContent=money(tw);$('#mg').textContent='Result '+r+'. You won ₹'+money(win)+'!'}
   else $('#mg').textContent='Result '+r+(bets.some(Boolean)?'. No win this round.':'');
   later(round,3500)},4400)}
 round();
}

