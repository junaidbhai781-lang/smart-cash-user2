/* ---------- GreedyBaby ---------- */
function greedy(gb){
 var F=[{e:'🍎',m:5,w:20},{e:'🍋',m:5,w:20},{e:'🍓',m:5,w:20},{e:'🥭',m:5,w:20},{e:'🐟',m:10,w:10},{e:'🍔',m:15,w:7},{e:'🍕',m:25,w:4},{e:'🍗',m:45,w:2}],
 POS=[0,1,2,5,8,7,6,3],bets=[0,0,0,0,0,0,0,0],busy=false,t=15,tw=today.greedy||0,hist=[];
 var html='';for(var p=0;p<9;p++){var k=POS.indexOf(p);html+=k<0?'<div class="mid" id="md"><div><span class="e">🐻‍❄️</span><b id="cd">15</b><small id="ph">Bet time</small></div></div>':'<button class="fd" data-i="'+k+'"><span class="e">'+F[k].e+'</span><span class="m">x'+F[k].m+'</span></button>'}
 gb.innerHTML='<div class="stat"><div><b id="tw">'+money(tw)+'</b><i>Today\'s win</i></div></div><div class="ring">'+html+'</div><div class="msg" id="mg">Choose the wager, then choose food</div>'+chipsHTML()+'<div class="hist"><em>Results</em><span id="hs"></span></div>';
 var cv=chipPick(gb),fds=$$('.fd',gb);
 var byI={};fds.forEach(function(b){byI[b.dataset.i]=b});
 fds.forEach(function(b){b.onclick=function(){var i=+b.dataset.i,v=cv();if(busy)return toast('Drawing in progress');if(wallet<v)return toast('Insufficient balance');setW(wallet-v);bets[i]+=v;draw(i)}});
 function draw(i){var b=byI[i],m=$('.my',b);if(!m){m=document.createElement('span');m.className='my';b.appendChild(m)}m.textContent=fmt(bets[i])}
 function round(){busy=false;t=15;bets=[0,0,0,0,0,0,0,0];fds.forEach(function(b){b.classList.remove('win','hl');var m=$('.my',b);if(m)m.remove()});$('#ph').textContent='Bet time';$('#cd').textContent=t;$('#mg').textContent='Place your bets';
  var iv=every(function(){t--;$('#cd').textContent=t+'s';if(t<=0){clearInterval(iv);go()}},1000)}
 function go(){busy=true;$('#ph').textContent='Drawing';$('#cd').textContent='...';var w=pickW(F.map(function(f,i){return {w:f.w,i:i}})).i,steps=24+w+(8-(24%8)),cur=0,n=0;
  var total=16+((w-0+8)%8),sp=70;
  (function tick(){fds.forEach(function(b){b.classList.remove('hl')});byI[cur%8].classList.add('hl');
   if(n>=total+8&&cur%8==w){return end(w)}n++;cur++;sp=n>total?sp+25:70;later(tick,sp)})()}
 function end(w){byI[w].classList.add('win');var win=bets[w]*F[w].m;hist.unshift(F[w].e);hist=hist.slice(0,8);$('#hs').textContent=hist.join(' ');$('#cd').textContent=F[w].e;
  if(win){setW(wallet+win);tw+=win;today.greedy=tw;$('#tw').textContent=money(tw);$('#mg').textContent=F[w].e+' won! You got ₹'+money(win)}
  else $('#mg').textContent=F[w].e+' was the winner'+(bets.some(Boolean)?'. No win this round.':'');
  later(round,3200)}
 round();
}
